<link rel="stylesheet" href="Main.css">
<hr>
	<footer class="align-bottom">
		<div class="footerSponser" style="width: 100%">
			<ul class="sponser">
				<li>
					<a href="" target="_blank">
						<img src="https://previews.123rf.com/images/artrise/artrise1806/artrise180600022/103576938-cinema-logo-vector-emblem-template.jpg" alt="">
					</a>
				</li>
				<li>
					<a href="" target="_blank">
						<img src="https://scalebranding.com/wp-content/uploads/2021/02/c-cinema-logo.jpg" alt="">
					</a>
				</li>
				<li>
					<a href="" target="_blank">
						<img src="https://kff.kz/uploads/images/2020/10/01/5f75932432a9c_avatar.png" alt="">
					</a>
				</li>
				<li>
					<a href="" target="_blank">
						<img src="https://kff.kz/uploads/images/2018/07/25/5b58a6e45608d_avatar.png" alt="">
					</a>
				</li>
				<li>
					<a href="">
						<img src="https://kff.kz/uploads/images/2018/07/25/5b58a6dd1df12_avatar.png" alt="">
					</a>
				</li>
				<li>
					<a href="">
						<img src="https://kff.kz/uploads/images/2019/02/11/5c6137219df1e_avatar.png" alt="">
					</a>
				</li>
				<li>
					<a href="">
						<img src="https://kff.kz/uploads/images/2018/07/25/5b58a6f7660fe_avatar.png" alt="">
					</a>
				</li>
				<li></li>
			</ul>
		</div>
	</footer>
	<div class="footer">
		<div class="block3">
			<section class="foooterSection">
				<form action="check.php" method="post">
					<article class="article1">
						<h2>Contacts</h2>
						<input type="text" name="name" class="form-control" placeholder="Your name"><br>
						<input type="text" name="email" class="form-control" placeholder="Your email"><br>
						<input type="text" name="message" class="inputmes form-control" placeholder="Your message"><br>
						<div align="center">
							<input align="center" class="btn" name="send" type="submit" value="SEND">
						</div>
					</article>
				</form>
				<article class="article2">	
					<p>ilyas_dyusembaev@mail.ru</p>
					<p>8 775 544 60 35</p>
					<p>orazbaymukhtar@gmail.com</p>
					<p>8 778 911 86 30</p>
					<p>rererin@gmail.com</p>
					<p>8 708 273 06 78</p>
				</article>
			</section>
		</div>
	</div>
	<div class="copyright" style="color: #37003c">
		<div class="d-flex flex-wrap flex-row justify-content-between align-items-center w-100">
			<div class="col-lg-3 text-center">
				© Cinema industry 2021
			</div>
			<div class="col-lg-6">
				<ul class="d-flex flex-row justify-content-around" style="list-style: none;">
					<li><a href="#" style="color: #37003c;">Terms & Conditions</a></li>
					<li><a href="#" style="color: #37003c;">Policies</a></li>
					<li><a href="#" style="color: #37003c;">Cookie Policy</a></li>
				</ul>
			</div>
			<div class="col-lg-3 d-flex justify-content-center">
				<a href="Main.php"><img src="" alt="phoneicon" class="navbar-brand" style="width: 100px;"></a>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>