<link rel="stylesheet" href="Main.css">
<nav class="navbar navbar-expand-md navbar-dark sticky-top" style="background-color: #37003c">
		<a href="Main.php"><img src="" alt="phoneicon" class="navbar-brand" style="width: 100px;"></a>
		<div class="">
			<ul class="navbar-nav">
					<li class="nav-item px-3">
						<a href="#" class="nav-link">TEXT_TEXT_TEXT</a>
					</li>
			   </ul>
		</div>
		<button class="navbar-toggler" data-toggle="collapse" data-target="#navbarMenu">
		   <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse w-100 justify-content-end" id="navbarMenu">
			<div class="dropdown">
				<a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					TEXT_TEXT_TEXT
				</a>

				<div class="dropdown-menu drop" aria-labelledby="dropdownMenuLink" style="background-color: #37003c">
					<a class="dropdown-item" style="color: #0086ff" href="Main.php">TEXT</a>
					<a class="dropdown-item" style="color: #0086ff" href="#">TEXT</a>
					<a class="dropdown-item" style="color: #0086ff" href="#">TEXT</a>
				</div>
			</div>
			<div>
			   <ul class="navbar-nav">
					<li class="nav-item mx-2">
						<a href="#" class="nav-link">TEXT</a>
					</li>
					<li class="nav-item mx-2">
						<a href="#" target="_blank" class="nav-link">TEXT</a>
					</li>
			   </ul>
			</div>
		</div>
	</nav>